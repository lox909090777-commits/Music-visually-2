package com.example.musicviz

import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

class VizWallpaper : WallpaperService() {

    override fun onCreateEngine(): Engine = VizEngine()

    inner class VizEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val cfg = Cfg(this@VizWallpaper)
        private var visible = false
        private val tick = object : Runnable {
            override fun run() {
                draw()
                if (visible) handler.postDelayed(this, 33)
            }
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            handler.removeCallbacks(tick)
            if (v) handler.post(tick)
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(tick)
            super.onSurfaceDestroyed(holder)
        }

        private fun draw() {
            val c = surfaceHolder.lockHardwareCanvas() ?: return
            try {
                Viz.draw(c, c.width.toFloat(), c.height.toFloat(), Spectrum.bands, cfg, true)
            } finally {
                surfaceHolder.unlockCanvasAndPost(c)
            }
        }
    }
}
