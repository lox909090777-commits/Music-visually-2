package com.example.musicviz

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import kotlin.math.*

object Viz {
    fun render(bands: FloatArray, w: Int, h: Int, cfg: Cfg): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        draw(Canvas(bmp), w.toFloat(), h.toFloat(), bands, cfg, false)
        return bmp
    }

    /** full = true для живых обоев: фон на весь экран, без прозрачности и скруглений. */
    fun draw(c: Canvas, w: Float, h: Float, bands: FloatArray, cfg: Cfg, full: Boolean) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val style = cfg["style"]
        val n = cfg["bars"]
        val gain = cfg["gain"] / 100f
        val amp = cfg["height"] / 100f
        val thick = cfg["width"] / 100f
        val roundK = cfg["round"] / 100f
        val mode = cfg["colorMode"]
        val sat = cfg["sat"] / 100f
        val hue1 = cfg["hue1"].toFloat()
        val hue2 = cfg["hue2"].toFloat()

        // фон
        val bgA = if (full) 255 else cfg["bgAlpha"] * 255 / 100
        val bgR = if (full) 0f else min(w, h) * cfg["bgRadius"] / 100f
        paint.color = Color.HSVToColor(bgA, floatArrayOf(cfg["bgHue"].toFloat(), 0.5f, cfg["bgBri"] / 100f))
        c.drawRoundRect(0f, 0f, w, h, bgR, bgR, paint)

        fun colorAt(t: Float): Int {
            val hue = when (mode) {
                0 -> hue1
                1 -> hue1 + (hue2 - hue1) * t
                else -> 300f * t
            }
            return Color.HSVToColor(floatArrayOf(((hue % 360f) + 360f) % 360f, sat, 1f))
        }
        fun colorOf(i: Int) = colorAt(if (n <= 1) 0f else i / (n - 1f))
        fun grad(xa: Float, xb: Float) =
            LinearGradient(xa, 0f, xb, 0f, IntArray(7) { colorAt(it / 6f) }, null, Shader.TileMode.CLAMP)
        fun lv(t: Float): Float {
            val pos = t.coerceIn(0f, 1f) * (bands.size - 1)
            val a = pos.toInt()
            val b = min(a + 1, bands.size - 1)
            val f = pos - a
            return ((bands[a] * (1 - f) + bands[b] * f) * gain).coerceIn(0f, 1f)
        }
        fun level(i: Int) = lv(if (n <= 1) 0f else i / (n - 1f))

        val x0 = w * 0.06f
        val inner = w - 2 * x0
        val slot = inner / n
        val bw = slot * thick
        val rad = bw / 2 * roundK

        when (style) {
            0, 1 -> for (i in 0 until n) {
                val v = level(i)
                val x = x0 + i * slot + (slot - bw) / 2
                paint.color = colorOf(i)
                if (style == 0) {
                    val bh = h * 0.42f * amp * v + 2f
                    c.drawRoundRect(x, h / 2 - bh, x + bw, h / 2 + bh, rad, rad, paint)
                } else {
                    val bh = h * 0.8f * amp * v + 2f
                    c.drawRoundRect(x, h * 0.9f - bh, x + bw, h * 0.9f, rad, rad, paint)
                }
            }

            2 -> { // одна полоса
                var s = 0f
                for (b in bands) s += b
                val lvl = (s / bands.size * 2.2f * gain).coerceIn(0f, 1f)
                val th = h * 0.55f * thick
                val top = (h - th) / 2
                val r = th / 2 * roundK
                paint.color = (colorAt(0f) and 0x00FFFFFF) or (45 shl 24)
                c.drawRoundRect(x0, top, x0 + inner, top + th, r, r, paint)
                if (mode == 0) paint.color = colorAt(0f) else paint.shader = grad(x0, x0 + inner)
                c.drawRoundRect(x0, top, x0 + max(inner * lvl, min(th, inner)), top + th, r, r, paint)
                paint.shader = null
            }

            3 -> { // волна
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = max(2f, h * 0.08f * thick)
                paint.strokeCap = Paint.Cap.ROUND
                paint.strokeJoin = Paint.Join.ROUND
                if (mode == 0) paint.color = colorAt(0f) else paint.shader = grad(x0, x0 + inner)
                for (sgn in intArrayOf(-1, 1)) {
                    val path = Path()
                    var px = 0f
                    var py = 0f
                    for (i in 0 until n) {
                        val x = x0 + inner * i / max(1, n - 1)
                        val y = h / 2 + sgn * (h * 0.42f * amp * level(i) + 1f)
                        if (i == 0) path.moveTo(x, y) else path.quadTo(px, py, (px + x) / 2, (py + y) / 2)
                        px = x
                        py = y
                    }
                    path.lineTo(px, py)
                    c.drawPath(path, paint)
                }
                paint.shader = null
                paint.style = Paint.Style.FILL
            }

            4 -> { // круг
                val m = min(w, h)
                val r0 = m * 0.2f
                paint.style = Paint.Style.STROKE
                paint.strokeCap = if (roundK > 0.5f) Paint.Cap.ROUND else Paint.Cap.BUTT
                paint.strokeWidth = max(2f, 2f * PI.toFloat() * r0 / n * thick)
                for (i in 0 until n) {
                    val a = (2.0 * PI * i / n - PI / 2).toFloat()
                    val k = (if (i <= n / 2) i else n - i) / (n / 2f)
                    val len = m * 0.28f * amp * lv(k) + 2f
                    paint.color = colorOf(i)
                    c.drawLine(
                        w / 2 + cos(a) * r0, h / 2 + sin(a) * r0,
                        w / 2 + cos(a) * (r0 + len), h / 2 + sin(a) * (r0 + len), paint
                    )
                }
                paint.style = Paint.Style.FILL
            }

            5 -> { // точки
                val rows = 8
                val cellH = h * 0.8f * amp / rows
                val dr = min(slot, cellH) / 2 * thick
                for (i in 0 until n) {
                    val lit = (level(i) * rows).roundToInt()
                    val cx = x0 + slot * (i + 0.5f)
                    for (r in 0 until rows) {
                        paint.color = if (r < lit) colorOf(i) else (colorOf(i) and 0x00FFFFFF) or (35 shl 24)
                        c.drawCircle(cx, h * 0.9f - cellH * (r + 0.5f), dr, paint)
                    }
                }
            }

            else -> { // пульс: один круг
                var bass = 0f
                for (i in 0 until 6) bass += bands[i]
                bass = (bass / 6 * gain * 1.4f).coerceIn(0f, 1f)
                var hi = 0f
                for (i in 12 until bands.size) hi += bands[i]
                hi = (hi / (bands.size - 12) * gain * 2f).coerceIn(0f, 1f)
                val m = min(w, h) / 2
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = max(2f, m * 0.08f * thick)
                paint.color = colorAt(1f)
                c.drawCircle(w / 2, h / 2, m * (0.5f + 0.4f * hi * amp), paint)
                paint.style = Paint.Style.FILL
                paint.color = colorAt(0f)
                c.drawCircle(w / 2, h / 2, m * (0.15f + 0.4f * bass * amp), paint)
            }
        }
    }
}
