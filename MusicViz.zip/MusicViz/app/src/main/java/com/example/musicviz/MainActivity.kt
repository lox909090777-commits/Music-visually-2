package com.example.musicviz

import android.Manifest
import android.app.Activity
import android.app.WallpaperManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.widget.*
import kotlin.math.sin

class MainActivity : Activity() {
    private lateinit var cfg: Cfg
    private lateinit var col: LinearLayout
    private lateinit var preview: ImageView
    private val ui = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            val b = Spectrum.bands
            val src = if (b.max() > 0.02f) b else demo(SystemClock.uptimeMillis())
            preview.setImageBitmap(Viz.render(src, 600, 240, cfg))
            ui.postDelayed(this, 80)
        }
    }

    private fun demo(t: Long) = FloatArray(Spectrum.BANDS) { i ->
        val v = 0.5f + 0.5f * sin(t / 250.0 + i * 0.45).toFloat()
        (v * (1f - i * 0.015f)).coerceIn(0.05f, 1f)
    }

    private fun head(t: String) {
        col.addView(TextView(this).apply { text = t; textSize = 18f; setPadding(0, 40, 0, 8) })
    }

    private fun btn(t: String, f: () -> Unit) {
        col.addView(Button(this).apply { text = t; setOnClickListener { f() } })
    }

    private fun slider(label: String, key: String, min: Int, max: Int, unit: String = "", hue: Boolean = false) {
        val tv = TextView(this)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = cfg[key] - min
        fun upd() {
            val v = sb.progress + min
            tv.text = "$label: $v$unit"
            if (hue) tv.setTextColor(Color.HSVToColor(floatArrayOf(v.toFloat(), 1f, 1f)))
        }
        upd()
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { cfg[key] = p + min; upd() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { VizWidget.push(this@MainActivity, Spectrum.bands) }
        })
        col.addView(tv)
        col.addView(sb)
    }

    private fun choice(label: String, key: String, items: List<String>) {
        col.addView(TextView(this).apply { text = label })
        col.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(cfg[key])
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    if (cfg[key] != pos) {
                        cfg[key] = pos
                        VizWidget.push(this@MainActivity, Spectrum.bands)
                    }
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Cfg(this)
        val dp = resources.displayMetrics.density
        preview = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 220)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 110, 32, 0)
            addView(preview, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (180 * dp).toInt()))
            addView(ScrollView(this@MainActivity).apply { addView(col) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(root)

        btn("Запустить захват звука") { startCapture() }
        btn("Остановить захват") { stopService(Intent(this, CaptureService::class.java)) }
        btn("Добавить виджет на рабочий стол") {
            val awm = getSystemService(AppWidgetManager::class.java)
            if (awm.isRequestPinAppWidgetSupported) {
                awm.requestPinAppWidget(ComponentName(this, VizWidget::class.java), null, null)
            } else {
                Toast.makeText(this, "Долгое нажатие на рабочем столе → Виджеты → MusicViz", Toast.LENGTH_LONG).show()
            }
        }
        btn("Живые обои (экран блокировки)") {
            startActivity(
                Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    ComponentName(this, VizWallpaper::class.java)
                )
            )
        }

        head("Вид")
        choice("Стиль", "style", listOf(
            "Столбики от центра", "Столбики снизу", "Одна полоса", "Волна",
            "Круг", "Точки (эквалайзер)", "Пульс (один круг)"
        ))
        slider("Количество полос", "bars", 6, 64)
        slider("Толщина", "width", 10, 100, " %")
        slider("Скругление", "round", 0, 100, " %")
        slider("Высота", "height", 20, 100, " %")
        slider("Чувствительность", "gain", 50, 300, " %")

        head("Цвет")
        choice("Режим цвета", "colorMode", listOf("Один цвет", "Градиент", "Радуга"))
        slider("Цвет 1", "hue1", 0, 360, "°", true)
        slider("Цвет 2 (для градиента)", "hue2", 0, 360, "°", true)
        slider("Насыщенность (0 = белый)", "sat", 0, 100, " %")

        head("Фон")
        slider("Оттенок фона", "bgHue", 0, 360, "°", true)
        slider("Яркость фона", "bgBri", 0, 100, " %")
        slider("Непрозрачность фона (0 = без фона)", "bgAlpha", 0, 100, " %")
        slider("Скругление углов виджета", "bgRadius", 0, 50, " %")

        head("Скорость")
        slider("Кадров в секунду (виджет)", "fps", 4, 20)

        btn("Сбросить настройки") {
            cfg.reset()
            VizWidget.push(this, Spectrum.bands)
            recreate()
        }
    }

    override fun onResume() { super.onResume(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }

    private fun startCapture() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            val perms = if (Build.VERSION.SDK_INT >= 33)
                arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
            else arrayOf(Manifest.permission.RECORD_AUDIO)
            requestPermissions(perms, 1)
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), 2)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startCapture()
        else Toast.makeText(this, "Нужно разрешение на запись звука", Toast.LENGTH_LONG).show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 2 && resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, CaptureService::class.java)
                    .putExtra("code", resultCode)
                    .putExtra("data", data)
            )
        }
    }
}
