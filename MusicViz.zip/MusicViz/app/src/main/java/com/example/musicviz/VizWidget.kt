package com.example.musicviz

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.widget.RemoteViews

class VizWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, awm: AppWidgetManager, ids: IntArray) {
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        for (id in ids) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget)
            rv.setImageViewBitmap(R.id.img, bitmap(ctx, awm, id, Spectrum.bands))
            rv.setOnClickPendingIntent(R.id.img, open)
            awm.updateAppWidget(id, rv)
        }
    }

    override fun onAppWidgetOptionsChanged(ctx: Context, awm: AppWidgetManager, id: Int, o: Bundle) {
        push(ctx, Spectrum.bands)
    }

    companion object {
        private fun bitmap(ctx: Context, awm: AppWidgetManager, id: Int, b: FloatArray): Bitmap {
            val o = awm.getAppWidgetOptions(id)
            val d = ctx.resources.displayMetrics.density * 0.6f
            val w = (o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250) * d).toInt().coerceIn(80, 420)
            val h = (o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110) * d).toInt().coerceIn(40, 220)
            return Viz.render(b, w, h, Cfg(ctx))
        }

        /** Перерисовывает все виджеты MusicViz с новыми данными. */
        fun push(ctx: Context, b: FloatArray) {
            try {
                val awm = AppWidgetManager.getInstance(ctx)
                val ids = awm.getAppWidgetIds(ComponentName(ctx, VizWidget::class.java))
                for (id in ids) {
                    val rv = RemoteViews(ctx.packageName, R.layout.widget)
                    rv.setImageViewBitmap(R.id.img, bitmap(ctx, awm, id, b))
                    awm.partiallyUpdateAppWidget(id, rv)
                }
            } catch (_: Exception) {}
        }
    }
}
