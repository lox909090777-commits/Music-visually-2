package com.example.musicviz

import android.content.Context

/** Настройки внешнего вида (общие для виджета, обоев и превью). */
class Cfg(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("viz", Context.MODE_PRIVATE)

    operator fun get(k: String): Int = p.getInt(k, DEF.getValue(k))
    operator fun set(k: String, v: Int) { p.edit().putInt(k, v).apply() }
    fun reset() { p.edit().clear().apply() }

    companion object {
        val DEF = mapOf(
            "style" to 0, "bars" to 32, "width" to 70, "round" to 100,
            "height" to 80, "gain" to 120,
            "colorMode" to 1, "hue1" to 190, "hue2" to 320, "sat" to 75,
            "bgHue" to 240, "bgBri" to 7, "bgAlpha" to 85, "bgRadius" to 20,
            "fps" to 10
        )
    }
}
